const gl = "receiver100merchant1745654046826vdl0va6m96tir5a51sba";
async function sha256(...messages) {
    let str = messages.join("")
    console.log([str])
  let s = String.fromCharCode(
    ...(
      new Uint8Array(
        await crypto.subtle.digest(
          'SHA-256',
          (
            new TextEncoder()
          ).encode(
            str
          )
        )
      )
    )
    );
  console.log(s);
  // console.log(sha256Hash(str));
  
  // console.log([str, gl]);
    return s;
}


// async function sha256Hash(input) {
//     const encoder = new TextEncoder();
//     const data = encoder.encode(input);
//     const hashBuffer = await crypto.subtle.digest('SHA-256', data);
//     const hashArray = Array.from(new Uint8Array(hashBuffer));
//     const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
//     return hashHex;
// }


export default sha256; // Correctly export the sha256 function