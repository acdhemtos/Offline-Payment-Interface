// Simulating biometric authentication

async function biometric() {
  try {
    await navigator.credentials.create({
      publicKey: {
        challenge: new Uint8Array(16), // Random challenge
        rp: { name: "My App" }, // Relying party (your app)
        user: {
          id: new Uint8Array(8), // Unique user ID
          name: "user@example.com", // User's email or username
          displayName: "User", // User's display name
        },
        pubKeyCredParams: [
          { type: "public-key", alg: -7 }, // ES256 (ECDSA with SHA-256)
          { type: "public-key", alg: -257 }, // RS256 (RSA with SHA-256)
        ],
        authenticatorSelection: {
          authenticatorAttachment: "platform", // Built-in biometrics
          userVerification: "required", // Triggers biometrics
        },
        timeout: 60000, // Timeout in milliseconds
        attestation: "none", // No attestation required
      },
    });
  } catch (err) {
    console.error("Biometric authentication failed:", err);
    return false;
  }
  return true;
}

export default biometric;