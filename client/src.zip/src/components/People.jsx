import React from "react";
import { FaUserPlus } from "react-icons/fa";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { Pagination, Navigation } from "swiper/modules";

const People = ({ contacts }) => {
  return (
    <section className="w-full px-3 mb-10">
      <div className="bg-slate-100 rounded-xl shadow-md mx-2 py-6 px-2 border-blue-200 border-2">
        <h2 className="text-lg font-medium text-gray-800 mb-4 px-2">People</h2>

        {/* Swiper Slider */}
        <Swiper
          breakpoints={{
            320: { slidesPerView: 4, spaceBetween: 0 },
            640: { slidesPerView: 3, spaceBetween: 15 },
            768: { slidesPerView: 4, spaceBetween: 20 },
            1024: { slidesPerView: 5, spaceBetween: 25 },
          }}
          pagination={{
            clickable: true,
            dynamicBullets: true,
          }}
          navigation={true}
          modules={[Pagination, Navigation]}
          className="pb-4"
        >
          {contacts.map((contact) => (
            <SwiperSlide key={contact.id} className="flex justify-center">
              <div className="flex flex-col items-center">
                <div
                  className={`${contact.bgColor} w-10 h-10 rounded-full flex items-center justify-center text-white font-medium text-xl shadow-md`}
                >
                  {contact.id === 8 ? (
                    <FaUserPlus className="text-white text-xl" />
                  ) : (
                    contact.initial
                  )}
                </div>
                <p className="mt-2 text-xs font-medium text-gray-700 text-center">
                  {contact.name}
                </p>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>

        {/* Inline CSS for arrows and dots */}
        <style jsx>{`
   .swiper-button-next,
          .swiper-button-prev {
            background-color: transparent;
            border-radius: 9999px;
            width: 24px;
            height: 24px;
            top: 60%; /* Move up or down */
            transform: translateY(-50%);
            z-index: 10;
          }

  .swiper-button-prev {
    left: -6px; /* move more left (negative) or less left (positive) */
  }

  .swiper-button-next {
    right: -6px; /* move more right (negative) or less right (positive) */
  }

  .swiper-button-next::after,
  .swiper-button-prev::after {
    font-size: 16px;
    font-weight: bold;
  }

  .swiper-pagination {
    bottom: 0px !important; /* move bullets lower */
  }

  .swiper-pagination-bullet {
    background-color: #cbd5e1;
    opacity: 1;
    width: 8px;
    height: 8px;
    margin: 0 4px;
    border-radius: 9999px;
    transition: all 0.3s ease;
  }

  .swiper-pagination-bullet-active {
    background-color: #2563eb;
    width: 12px;
    height: 12px;
  }
`}</style>

      </div>
    </section>
  );
};

export default People;
