import React, { useEffect, useState } from "react";
import Cookies from "js-cookie";
import { FaCog, FaQrcode, FaMobileAlt, FaUserPlus, FaMoneyBillWave, FaChartLine, FaHistory } from "react-icons/fa";
import { BsCreditCard2Front, BsArrowUpCircle, BsBank2, BsLightningCharge, BsChevronRight } from "react-icons/bs";
import People from "./People"; 
import { NavLink, useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  
  // const handleSettingsClick = () => {
  //   navigate("/settings"); // Navigate to the settings page
  // };
  const [username, setUsername] = useState("");
  const [balance, setBalance] = useState(0);
  const [isPinSet, setIsPinSet] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    // Fetch the username from the API
    const fetchUsername = async () => {
      try {
        const username = Cookies.get("username");
        const response = await fetch("/api/getName.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username }), 
        });
        const data = await response.json();
        if (data && data.name) {
          const capitalizedUsername = data.name.charAt(0).toUpperCase() + data.name.slice(1);
          setUsername(capitalizedUsername);
        }
      } catch (error) {
        console.error("Error fetching username:", error);
      }
    };
    const fetchBalance = async () => {
      try {
        const username = Cookies.get("username");
        const sessionKey = Cookies.get("session_key");
        const response = await fetch("/api/getBalance.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, session_key: sessionKey }),
        });
        const data = await response.json();
        console.log(data);
        if (data && data.balance !== undefined) {
          setBalance(data.balance/100);
        }
      } catch (error) {
        console.error("Error fetching balance:", error);
      }
    };
    const checkPinSet = async () => {
      try {
        const username = Cookies.get("username");
        const sessionKey = Cookies.get("session_key");
        const response = await fetch("/api/isPinSet.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, session_key: sessionKey }),
        });
        const data = await response.json();
        if (data && data.code === 0) {
          setIsPinSet(data.pinSet);
        }
      } catch (error) {
        console.error("Error checking PIN status:", error);
      }
    };
    
    fetchBalance();
    fetchUsername();
    checkPinSet();
  }, []);

  const handleLogout = async () => {
      try {
        // Get cookies
        const username = Cookies.get("username");
        const session_key = Cookies.get("session_key");
  
        console.log("Logout Payload:", { username, session_key }); // Debugging line
  
        if (!session_key || !username) {
          alert("Session key or username is missing. Unable to log out.");
          return;
        }
    
        // Send logout request to the backend
        const response = await fetch("/api/logout.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, session_key }),
        });
    
        const data = await response.json();
        console.log("Logout response:", data); // Debugging line
    
        if (data.code === 0) {
          // Clear cookies using js-cookie
          Cookies.remove("session_key", { path: "/" });
          Cookies.remove("username", { path: "/" });
          alert("You have been logged out.");
          window.location.href = "/";
        } else {
          alert("An error occurred during logout. Please try again.");
        }
      } catch (error) {
        console.error("Error during logout:", error); // Debugging line
        alert("An error occurred. Please try again later.");
      }
  };
  
  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const contacts = [
    { id: 1, name: "Alex", initial: "A", bgColor: "bg-blue-400" },
    { id: 2, name: "Priya", initial: "P", bgColor: "bg-green-400" },
    { id: 3, name: "Sam", initial: "S", bgColor: "bg-purple-400" },
    { id: 4, name: "Mike", initial: "M", bgColor: "bg-orange-400" },
    { id: 5, name: "Lisa", initial: "L", bgColor: "bg-pink-400" },
    { id: 6, name: "John", initial: "J", bgColor: "bg-yellow-400" },
    { id: 7, name: "Emma", initial: "E", bgColor: "bg-red-400" },
    { id: 8, name: "Add", initial: "+", bgColor: "bg-gray-200" }
  ];

  const services = [
    { id: 1, name: "Mutual Funds", icon: <FaChartLine className="text-xl" />, bgColor: "bg-blue-500" },
    { id: 2, name: "Fixed Deposit", icon: <BsBank2 className="text-xl" />, bgColor: "bg-purple-500" },
    { id: 3, name: "Gold Invest", icon: <FaMoneyBillWave className="text-xl" />, bgColor: "bg-yellow-500" },
    { id: 4, name: "Bill Payment", icon: <BsLightningCharge className="text-xl" />, bgColor: "bg-green-500" }
  ];

  

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-blue-50 to-blue-100 w-full">
      {/* Settings Button */}
      <div className="absolute top-6 right-6">
        <button
          onClick={toggleDropdown}
          className="text-slate-500 hover:text-black transition duration-300 ease-in-out transform hover:scale-110"
        >
          <FaCog className="text-2xl" />
        </button>
        {showDropdown && (
          <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
            <ul className="py-1">
              <li
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 cursor-pointer"
                onClick={() => {
                  if (isPinSet) {
                    alert("Redirecting to Change PIN page...");
                    // Redirect to Change PIN page
                  } else {
                    navigate("/app/set-pin")
                  }
                }}
              >
                {isPinSet ? "Change PIN" : "Set PIN"}
              </li>
              <li
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 cursor-pointer"
                onClick={handleLogout}
              >
                Logout
              </li>
            </ul>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex flex-col flex-1 justify-start items-center">
        {/* Welcome Message */}
        <div className="mt-20 mb-10 px-6 w-full max-w-md text-center">
          <h1 className="text-2xl font-bold text-gray-800">
            Hi, {username}!
          </h1>
          <p className="text-lg text-gray-600 mt-2">
            Your balance: ${balance.toFixed(2)}
          </p>
        </div>
        
        {/* Google Pay Style Icon Row with Slate Background */}
                <section className="w-full px-4 mb-6">
          <div className="bg-slate-100 rounded-xl shadow-md mx-auto py-4 px-4 border-blue-200 border-2 max-w-4xl">
            <div className="grid grid-cols-4 gap-2">
              {/* Scan */}
                            <div className="flex flex-col items-center">
                <div
                  className="bg-blue-500 text-white p-5 rounded-full shadow-md hover:bg-blue-600 transition duration-300 ease-in-out transform hover:scale-105 cursor-pointer"
                  onClick={() => navigate("/app/scan")} // Redirect to /app/scan
                >
                  <FaMobileAlt className="text-xl" />
                </div>
                <p className="mt-3 text-sm font-medium text-gray-700 text-center">Scan</p>
              </div>
        
              {/* QR */}
              <div className="flex flex-col items-center"
              onClick={() => navigate("/app/recieve")}
              >
                <div className="bg-green-500 text-white p-5 rounded-full shadow-md hover:bg-green-600 transition duration-300 ease-in-out transform hover:scale-105">
                  <FaQrcode className="text-xl" />
                </div>
                <p className="mt-3 text-sm font-medium text-gray-700 text-center">QR</p>
              </div>
        
              {/* Pay to UPI */}
              <div className="flex flex-col items-center"
              onClick={() => navigate("/app/send")} >
                <div className="bg-purple-500 text-white p-5 rounded-full shadow-md hover:bg-purple-600 transition duration-300 ease-in-out transform hover:scale-105">
                  <BsCreditCard2Front className="text-xl" />
                </div>
                <p className="mt-3 text-sm font-medium text-gray-700 text-center">Pay to UPI</p>
              </div>
        
              {/* Manage Top-up */}
              <div className="flex flex-col items-center">
                <div className="bg-red-500 text-white p-5 rounded-full shadow-md hover:bg-red-600 transition duration-300 ease-in-out transform hover:scale-105">
                  <BsArrowUpCircle className="text-xl" />
                </div>
                <p className="mt-3 text-sm font-medium text-gray-700 text-center">Top-up</p>
              </div>
            </div>
          </div>
        </section>

        <People contacts={contacts} /> 

               <section className="w-full px-3 mb-10">
          <div className="bg-slate-100 rounded-xl shadow-md mx-2 py-6 px-2 border-2 border-blue-200">
            <h2 className="text-lg font-medium text-gray-800 mb-4 px-2">Financial Services</h2>
            
            <div className="grid grid-cols-4 gap-6 px-2">
              {services.map((service) => (
                <div 
                  key={service.id} 
                  className="bg-white rounded-lg shadow-sm p-4 flex flex-col items-center hover:shadow-md transition-shadow duration-300"
                >
                  <div className={`${service.bgColor} p-3 rounded-full text-white mb-2`}>
                    {service.icon}
                  </div>
                  <span className="font-medium text-gray-800 text-center">{service.name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full px-4 mb-6">
          <div className="bg-slate-100 rounded-xl shadow-md mx-2">
            <button 
              className="w-full py-4 px-4 flex items-center justify-between hover:bg-slate-50 transition-colors duration-300 border-2 border-blue-200 rounded-lg"
              // onClick={handleTransactionHistoryClick}
            >
              <div className="flex items-center">
                <div className="bg-blue-100 text-blue-600 p-3 rounded-full mr-4">
                  <FaHistory className="text-xl" />
                </div>
                <span className="font-medium text-gray-800">See Transaction History</span>
              </div>
              <BsChevronRight className="text-gray-500" />
            </button>
          </div>
        </section>

        {/* Additional content can go here */}
        <div className="px-6 w-full max-w-md">
          {/* Recent transactions or other content */}
        </div>
      </div>
    </div>
  );
};

export default Home;