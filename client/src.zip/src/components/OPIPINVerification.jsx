import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import Cookies from "js-cookie";
import md5 from "md5";

const OPIQRCodeSVG = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const [qrData, setQrData] = useState("");
  const [receiverName, setReceiverName] = useState("");

  const { receiver, amount } = location.state || {};

  const fetchReceiverName = async (username) => {
    try {
      const response = await fetch("/api/getName.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username }),
      });
      const data = await response.json();
      if (data && data.name) {
        setReceiverName(data.name);
      }
    } catch (error) {
      console.error("Error fetching receiver name:", error);
    }
  };

  useEffect(() => {
    if (receiver) {
      fetchReceiverName(receiver);
    }
  }, [receiver]);

  useEffect(() => {
    const generateQRData = () => {
      const username = Cookies.get("username");
      const time = Math.floor(Date.now());
      const privateKey = Cookies.get("session_key");
      const hash = md5(`${username}.${receiverName}.${amount}.${time}.${privateKey}`);
      const qrDataString = `$\n${username}\n${time}\n${hash}\n$`;
      setQrData(qrDataString);
    };

    if (receiverName && amount) {
      generateQRData();
    }
  }, [receiverName, amount]);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error("Error accessing webcam:", error);
        alert("Unable to access the webcam.");
      }
    };

    startCamera();

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject;
        const tracks = stream.getTracks();
        tracks.forEach((track) => track.stop());
      }
    };
  }, []);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen bg-gray-100">
      {/* Back Button at top-left */}
      <button
        className="absolute top-4 left-4 bg-red-500 text-white px-6 py-2 rounded-lg text-lg shadow-md hover:bg-red-600 transition"
        onClick={() => navigate(-1)}
      >
        Back
      </button>

      {qrData && (
        <QRCodeSVG
          value={qrData}
          size={300}
          className="mb-6"
        />
      )}

      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full max-w-md border border-gray-300 rounded-lg opacity-[30%]"
      />
    </div>
  );
};

export default OPIQRCodeSVG;
