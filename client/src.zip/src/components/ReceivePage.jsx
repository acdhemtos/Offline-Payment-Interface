import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import { FaRupeeSign, FaArrowLeft } from "react-icons/fa";
import Cookies from "js-cookie";

const ReceivePage = () => {
  const [amount, setAmount] = useState("");
  const [qrData, setQrData] = useState("");
  const [username, setUsername] = useState("");
  const [isAmountDisabled, setIsAmountDisabled] = useState(false); // Track if amount input is disabled
  const videoRef = useRef(null);
  const inputRef = useRef(null);
  const navigate = useNavigate();

  // Fetch username from API and set it in state
  useEffect(() => {
    const fetchUsername = async () => {
      try {
        const username = Cookies.get("username");
        const response = await fetch("/api/getName.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username }),
        });
        const data = await response.json();
        if (data && data.name) {
          
          setUsername(data.name);

          // Initialize QR data with username
          setQrData(`$\n${username}\n$`);
        }
      } catch (error) {
        console.error("Error fetching username:", error);
      }
    };

    fetchUsername();
  }, []);

  // Handle input change and dynamically update QR code
  const handleInputChange = (e) => {
    const usersname = Cookies.get("username");
    const value = e.target.value;
    const [integerPart, decimalPart] = value.split(".");
    if (decimalPart && decimalPart.length > 2) {
      return; // Prevent input if there are already 2 decimal places
    }
    setAmount(value);

    // Update QR code data with amount
    if (value) {
      setQrData(`$\n${usersname}\n${value}\n${username}\n$`);
    } else {
      setQrData(`$\n${usersname}\n$`);
    }
  };

  const generateQRCode = async () => {
    setIsAmountDisabled(true); // Disable the amount input and hide input/button

    // Access camera for scanning
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      alert("Error accessing camera: " + error.message);
    }
  };

  return (
    <div className="flex flex-col min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-blue-100 w-full px-4">
      <header className="fixed top-0 left-0 right-0 p-4 bg-blue-600 text-white text-xl font-semibold shadow-md text-center w-full z-10">
        <button
          className="absolute top-3 left-4 text-white p-2 rounded-lg hover:bg-blue-600 transition"
          onClick={() => navigate(-1)}
          style={{ background: "none" }}
        >
          <FaArrowLeft className="text-2xl" />
        </button>
        Receive Money
      </header>

      {/* QR Code Display */}
      <div className="p-4 bg-white bg-opacity-20 backdrop-blur-lg rounded-lg mt-20 shadow-lg">
        <QRCodeSVG value={qrData} size={320} />
      </div>

      {/* Input Box and Button */}
      {!isAmountDisabled && (
        <>
          <div className="relative mb-4 w-full max-w-md mt-4">
            <FaRupeeSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              ref={inputRef}
              type="tel"
              className="pl-10 p-3 w-full border border-gray-300 rounded-lg text-center text-lg bg-white bg-opacity-20 backdrop-blur-lg cursor-pointer"
              placeholder="Enter Amount"
              value={amount}
              onChange={handleInputChange}
            />
          </div>

          <button
            className="mt-4 bg-blue-500 text-white px-6 py-3 rounded-lg text-lg shadow-lg hover:bg-blue-600 transition mb-4"
            onClick={generateQRCode}
          >
            Offline Sender
          </button>
        </>
      )}

      {/* Camera Feed */}
      {isAmountDisabled && (
        <div className="w-full max-w-md">
          <video
      ref={videoRef}
      autoPlay
      playsInline
      className="rounded-lg border border-gray-300"
      style={{
        width: "100vw", 
        height: "150px", 
        maxHeight: "100vh", 
        objectFit: "cover", 
      }}
    />
        </div>
      )}
    </div>
  );
};

export default ReceivePage;