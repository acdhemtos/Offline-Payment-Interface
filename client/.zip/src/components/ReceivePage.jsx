import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import { FaRupeeSign, FaArrowLeft } from "react-icons/fa";
import Cookies from "js-cookie";
import { encode } from "../utils/qrFunctions";
import { decode } from "../utils/qrFunctions";
import { AJAX } from "../utils/ajax";
import jsQR from "jsqr";



const ReceivePage = () => {
  const [uamount, setUamount] = useState("");
  const [qrData, setQrData] = useState("");
  const [username, setUsername] = useState("");
  const [isAmountDisabled, setIsAmountDisabled] = useState(false);
  const [backgroundColor, setBackgroundColor] = useState("bg-gradient-to-b from-blue-50 to-blue-100");
  const videoRef = useRef(null);
  const inputRef = useRef(null);
  const canvasRef = useRef(null); 
  const navigate = useNavigate();
  const [transactionStatus, setTransactionStatus] = useState("");
  
  const generateReceiveQR = (amount = "", name=false) => {
    // Encode username
    let qrString = encode.username(Cookies.get("username"));
    if (amount != "" ) {
      console.log(amount,amount*100)
      qrString += encode.amount(amount * 100);
      if (name !== false) {
        qrString += encode.name(name);
      }
    }
  
    console.log("Generated QR Data:", qrString);
    return qrString;
  };

  // Fetch username from API and set it in state
  useEffect(() => {
    const fetchUsername = async () => {
      setQrData(generateReceiveQR());
      
    };

    fetchUsername();
  }, []);

  // Handle input change and dynamically update QR code
  const handleInputChange = (e) => {
    const value = e.target.value;
    const [integerPart, decimalPart] = value.split(".");
    if (decimalPart && decimalPart.length > 2) {
      return; // Prevent input if there are already 2 decimal places
    }
    setUamount(value);
    setQrData(generateReceiveQR(value));
   
  };

 
  function base256ToBase16(base256String) {
    let base16String = '';
    
    // Convert each byte of the base 256 string to its hexadecimal representation
    for (let i = 0; i < base256String.length; i++) {
      const byte = base256String.charCodeAt(i);
      base16String += byte.toString(16).padStart(2, '0'); // Ensure each byte is two digits
    }
    
    return base16String;
  }
  const generateQRCode = async () => {
    const name = localStorage.getItem("name");
    console.log(name);
    const amount = uamount;
    setQrData(generateReceiveQR(amount, name));
    setIsAmountDisabled(true);
  
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
      });
  
      const video = videoRef.current;
      if (!video) return;
      video.srcObject = stream;
      video.play();
  
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
  
      const scan = async () => {
        if (video.readyState !== 4) {
          requestAnimationFrame(scan);
          return;
        }
  
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  
        const qrCode = jsQR(imageData.data, canvas.width, canvas.height);
        if (qrCode) {
          const rawValue = qrCode.data;
          console.log(rawValue);
          
          if (rawValue.length != 44) { requestAnimationFrame(scan); return; }
          let sender = decode.username(rawValue.slice(0, 10));
          let time = decode.time(rawValue.slice(10, 12));
          let details_hash = base256ToBase16(rawValue.slice(12, 44));
          if (sender === false || time == false || details_hash === false) {
            requestAnimationFrame(scan); return;
          }
          //close webcam
          const stopStream = () => {
            if (video.srcObject) {
              const stream = video.srcObject;
              const tracks = stream.getTracks();
              tracks.forEach((track) => track.stop());
              video.srcObject = null;
            }
            
            
          };
          stopStream();
          //clear qr
          setQrData("");
          //show sender
          //send request
          const sessionKey = Cookies.get("session_key");
          const username = Cookies.get("username");
          const amount = uamount * 100; // Convert amount to the smallest unit (e.g., paise)
          console.log("amount", uamount);

          const response = await AJAX("/api/receive.php", {
            username,
            session_key: sessionKey,
            amount,
            sender,
            time,
            details_hash,
          });
          console.log(response);

          if (response && response.code === 0) {
            console.log("code", response.code);
            setQrData(response.code);
            console.log("success",setQrData);
            setTransactionStatus("success");
          } else {
            // alert(response?.message || "Transaction failed. Please try again.");
            setTransactionStatus("failure");
          }
          
          //convey status
          if (response && response.code === 0) {
            setBackgroundColor("bg-green-500"); // Success
          } else {
            setBackgroundColor("bg-red-500"); // Failure
          }
          return;
        } else {
          requestAnimationFrame(scan); // keep scanning
        }
      };
  
      requestAnimationFrame(scan);
  
      // Clean up on component unmount
      const stopStream = () => {
        stream.getTracks().forEach(track => track.stop());
      };
  
      window.addEventListener("beforeunload", stopStream); // clean up if user closes window
      return () => {
        stopStream();
        window.removeEventListener("beforeunload", stopStream);
      };
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  };
  

  return (
    <div className={`flex flex-col min-h-screen items-center justify-center ${backgroundColor} w-full px-4`}>
      <header className="fixed top-0 left-0 right-0 p-4 bg-blue-600 text-white text-xl font-semibold shadow-md text-center w-full z-10">
        <button
          className="absolute top-3 left-4 text-white p-2 rounded-lg hover:bg-blue-600 transition"
          onClick={() => navigate(-1)}
          style={{ background: "none" }}
        >
          <FaArrowLeft className="text-2xl" />
        </button>
        Receive Money
      </header>

      {/* QR Code Display */}
      <div className="p-4 bg-white bg-opacity-20 backdrop-blur-lg rounded-lg mt-30 shadow-lg">
        <QRCodeSVG value={qrData} size={320} level="H" />
      </div>

      


      {/* Input Box and Button */}
      {!isAmountDisabled && (
        <>
          <div className="relative mb-20 w-full max-w-md mt-4">
            <FaRupeeSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              ref={inputRef}
              type="tel"
              className="pl-10 p-3 w-full border border-gray-300 rounded-lg text-center text-lg bg-white bg-opacity-20 backdrop-blur-lg cursor-pointer"
              placeholder="Enter Amount"
              value={uamount}
              onChange={handleInputChange}
            />
          </div>

          <button
            className="mt-4 bg-blue-500 text-white px-6 py-3 rounded-lg text-lg shadow-lg hover:bg-blue-600 transition mb-4"
            onClick={generateQRCode}
          >
            Offline Sender
          </button>
        </>
      )}

      {/* Camera Feed */}
      {isAmountDisabled && (
  <div className="w-full max-w-md relative">
    <video
      ref={videoRef}
      autoPlay
      playsInline
      className="rounded-lg border border-gray-300"
      style={{
        width: "100vw",
        height: "300px",
        maxHeight: "100vh",
        objectFit: "cover",
        transform: "rotateY(180deg)",
      }}
    />
    {transactionStatus && (
      <div className={`absolute inset-0 flex items-center justify-center rounded-lg text-3xl font-bold ${
        transactionStatus === "success" ? "bg-white/80 text-green-700" : "bg-white/80 text-red-700"
      }`}>
        {transactionStatus === "success" ? "Transaction Success ✅" : "Transaction Failed ❌"}
      </div>
    )}
  </div>
)}

    </div>
  );
};

export default ReceivePage;