import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import Cookies from "js-cookie";
import  sha256  from "../utils/sha256";
import { AJAX } from "../utils/ajax";
import {encode} from "../utils/qrFunctions"
import jsQR from "jsqr"; 
import { BsChatRight } from "react-icons/bs";
import { messages } from "../utils/loadMessages";

const OPIQRCodeSVG = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const canvasRef = useRef(null); // Add a canvas reference for QR code scanning
  const [qrData, setQrData] = useState("");
  const [receiverName, setReceiverName] = useState("");

  const { receiver, amount, rN } = location.state || {};
  console.log("receiver", receiver, rN);
 
  const adjustedAmount = amount ? Math.round(amount * 100) : 0; 

  useEffect(() => {
    if (receiver) {
      setReceiverName(receiver);
    }
  }, [receiver]);

  // const fetchReceiverName = async () => {
  //   try {
  //     const data = await AJAX("/api/getName.php");
  //     if (data && data.name) {
  //       setReceiverName(data.name);
  //     }
  //   } catch (error) {
  //     console.error("Error fetching receiver name:", error);
  //   }
  // };

  // useEffect(() => {
  //   if (receiver) {
  //     fetchReceiverName(receiver);
  //   }
  // }, [receiver]);

  useEffect(() => {
    const generateQRData = async() => {
      const username = encode.username(Cookies.get("username"));
      const tt = Date.now();
      const time = encode.time(tt)
      const privateKey = Cookies.get("private_key");
      
      console.log(receiver,adjustedAmount,rN,tt,privateKey);
      const hash = await sha256(receiver,adjustedAmount,rN,tt,privateKey);
      console.log(hash);
      console.log(`${receiver}, ${adjustedAmount}, ${rN}, ${tt}, ${privateKey}`);
      
console.log("ASCII Codes:", Array.from(hash).map(char => char.charCodeAt(0)));


      
    // Use recipient's username in the QR code data
    const qrDataString = username+time+hash;
      console.log(qrDataString);
    
    setQrData(qrDataString);
    };

    if (receiver && amount) {
      generateQRData();
      console.log(receiver);
    }
  }, [receiver, amount]);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current.play();
            requestAnimationFrame(scanQRCode); 
          };
        }
      } catch (error) {
        if (error.name === "NotAllowedError") {
          alert("Camera access denied.");
        }
        console.error("Error accessing webcam:", error);
        alert("Initialising the webcam.");
      }
    };

    const scanQRCode = () => {
      const video = videoRef.current;
      const canvas = canvasRef.current;

      if (video && canvas && video.videoWidth > 0 && video.videoHeight > 0) {
        const context = canvas.getContext("2d", { willReadFrequently: true });
        if (context) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;

          context.save();
          context.scale(-1, 1);
          context.translate(-canvas.width, 0);

          // Draw video frame onto the canvas
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
          context.restore();
          // Get image data from the canvas
          const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
          const code = parseInt(jsQR(imageData.data, canvas.width, canvas.height));
          console.log

          if (!isNaN(code)) {
            if (videoRef.current && videoRef.current.srcObject) {
              const stream = videoRef.current.srcObject;
              const tracks = stream.getTracks();
              tracks.forEach((track) => track.stop());
            }
            console.log(code.code==0 );
            alert(messages[code.data - 1] || "Login failed. Please try again.");
          }
        }
      }

      // Repeat the scan every animation frame
      requestAnimationFrame(scanQRCode);
    };

    startCamera();
    // scanQRCode();

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject;
        const tracks = stream.getTracks();
        tracks.forEach((track) => track.stop());
      }
    };
  }, []);

  return (
    <div className="relative flex flex-col items-center justify-start min-w-[100vw] min-h-screen bg-gray-100">
      {/* Back Button at top-left */}
      <button
        className="absolute top-4 left-4 bg-red-500 text-white px-6 py-2 rounded-lg text-lg shadow-md hover:bg-red-600 transition"
        onClick={() => navigate("/app/home")}
      >
        Back
      </button>

      {/* QR Code */}
      {qrData && (
        <div className="mt-20">
          <QRCodeSVG
            value={qrData}
            size={300}
            className="mb-6"
          />
        </div>
      )}

      {/* Webcam Feed */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full max-w-md border border-gray-300 rounded-lg opacity-[30%] transform scale-x-[-1]"
      />

      {/* Canvas for QR Code Scanning */}
          <canvas
        ref={canvasRef}
        className="absolute top-0 left-0 w-full h-full opacity-0 pointer-events-none transform scale-x-[-1]"
      />
    </div>
  );
};

export default OPIQRCodeSVG;